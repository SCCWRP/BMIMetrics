###Load Metadata

loadMetaData <- function(){
  load("inst/metadata.rdata")
  metadata
}
