#' Example benthic macroinvertebrate data frame
#' 
#' A data set of benthic macroinvertebrate count data from
#' 26 freshwater stream sites in southern California.
#' 
#' 
#' @docType data
#' @keywords datasets
#' @name bugdata
NULL